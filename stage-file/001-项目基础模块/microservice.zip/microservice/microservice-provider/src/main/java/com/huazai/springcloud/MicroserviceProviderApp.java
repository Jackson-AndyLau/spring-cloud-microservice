package com.huazai.springcloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceProviderApp
{

	public static void main(String[] args)
	{
		SpringApplication.run(MicroserviceProviderApp.class, args);
	}
}
